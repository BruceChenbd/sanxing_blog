/***
 * 我的剪辑数据结构
 */

const mongoose = require('mongoose');

module.exports = new mongoose.Schema({
    count: Number
})